#!/bin/sh
for((;;))
do
        mysql -uradius -phehe123 -e "use radius; UPDATE radacct SET acctstoptime = NOW() WHERE acctstoptime IS NULL AND TIMESTAMPDIFF(SECOND, acctstarttime, NOW()) - acctsessiontime >= 180";
        sleep 120
done
