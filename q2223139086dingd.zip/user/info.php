﻿<?php
include("head.php");
include("userinfo.php");
?>

<?php
    echo "<body style='background-color:#009ad6'></body>";
   // 
?>
<!DOCTYPE html>

<html lang="zh-cn">

<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>个人管理中心</title>
  <meta name="keywords" content=""/>
  <meta name="description" content=""/>
  <link href="css/bootstrap.min.css" rel="stylesheet"/>
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</head>
<body>  <nav class="navbar navbar-fixed-top navbar-default">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">导航按钮</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
 </button>

        <a href="#"><span class="glyphicon glyphicon-user"></span>尊敬的<?php echo $_SESSION['username'];?> ，欢迎您来到个人管理中心</a>


      </div><!-- /.navbar-header -->
      <div id="navbar" class="collapse navbar-collapse">
        <ul class="nav navbar-nav navbar-right">
          <li class="active">

          </li>


<a href="./login.php?act=logout"><span class="glyphicon glyphicon-log-out"></span> 退出登陆</a>
          </li>
        </ul>
      </div><!-- /.navbar-collapse -->
    </div><!-- /.container -->
  </nav><!-- /.navbar -->

<div class="container" style="padding-top:180px;">
	<div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;margin-top: -100px;">
		<div class="panel panel-success" >
			<div class="panel-heading">
				<h3 class="panel-title">
					

					您的账户信息
				</h3>

			</div>
   <table class="table">
     <tr><td>公告:<span class="badge">苹果用户请看底部下载线路</span>

      <tr><td>当前账户:<span class="label label-success"><?php echo $_SESSION['username'];?></span></td></tr>
    <tr><td>套餐天数:<span class="label label-danger"><?php echo $data['maxActiveDays'];?>天</span></td></tr>
    <tr><td>已用天数:<span class="label label-danger"><?php echo $data['activeDaysCount'];?>天</span></td></tr>
      <tr><td>套餐流量:<span class="label label-info"><?php echo $data['maxGlobalTraffic'];?>GB</span></td></tr>
      <tr><td>已用流量:<span class="label label-info"><?php echo $data['globalTrafficCount'];?>GB</span></td></tr>

   </table>
  	<div class="alert alert-success" >
				                                    提示:

				<br />
				                                     1.流量有效期以剩余天数为准！

				<br />
2.如果流量数据没有更新请断开VPN连接重新查询！
				<br />

			</div>
				<div class="form-group">&nbsp;
				<a href="line.php"><button type="button" class="btn btn-success">安装线路</button></a>&nbsp;
				<a href="http://xlt.qingyi66.com/ "><button type="icon-bar" class="btn btn-success">推荐线路</button></a>&nbsp;

				<a href="help.html"><button type="icon-bar" class="btn btn-success">使用帮助</button></a>&nbsp;



			<br/>
			</div>
			</div>
			</div>
  

</script>

 