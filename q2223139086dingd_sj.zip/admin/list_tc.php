<?php
include('head.php');
include('nav.php');
?><style>
.row-col{
		background:#fff;
		border:1px solid #ccc;
		border-top:1px solid #ddd;
		border-left:1px solid #ddd;
		padding:15px;
	}
.sub{
	font-size:16px;
}
	.row-col h3{
		color:#777;
	}
	.row-col p{
		padding:15px;
	}</style>
<?php 	
 	if($_GET['act'] == 'del'){
		$db = db('radgroupcheck');
		if($db->where(array('groupname'=>$_POST['id']))->delete()){
			db("radgroupcheck")->where(array('groupname'=>$_POST['id']))->delete();
			die(json_encode(array("status"=>'success')));
		}else{
			die(json_encode(array("status"=>'error')));
		}
		
	}elseif($_GET['act'] == 'show'){
		$show = $_POST['show'] == '1' ? "1" : "0";
		$db = db('app_tc');
		if($db->where(array('id'=>$_POST['id']))->update(array('show'=>$show))){
			die(json_encode(array("status"=>'success')));
		}else{
			die(json_encode(array("status"=>'error')));
		}
		
	}else{
 ?>
<div class="main">
	<div class="row">
	<?php 
		//$db = db('app_tc');
		$list = db('radgroupcheck')->where(array())->field('DISTINCT(groupname)')->select();
		foreach($list as $vo){
		$list_groupname = $vo['groupname'];
		$vos_ll = db('radgroupcheck')->where("groupname = '$list_groupname' and attribute = 'Max-Global-Traffic'")->field('SUM(value)')->select();//流量
		$vos_ts = db('radgroupcheck')->where("groupname = '$list_groupname' and attribute = 'Max-Active-Days'")->field('SUM(value)')->select();//天数
		$vos_zx = db('radgroupcheck')->where("groupname = '$list_groupname' and attribute = 'Simultaneous-Use'")->field('SUM(value)')->select();//人数
		$vos_zx[0]['SUM(value)'] = $vos_zx[0]['SUM(value)'] ? $vos_zx[0]['SUM(value)'] : 999;
		$vos_ll[0]['SUM(value)'] = $vos_ll[0]['SUM(value)'] ? $vos_ll[0]['SUM(value)'] : 999*1024;
echo '<div class="col-xs-6 col-sm-3 text-center line-id-'.$vo['id'].'">';
	echo '<div class="row-col c_active div_shadow">';
      echo '<h3>'.$vo['groupname'].'</h3>';
		// echo '<div class="sub">价格：'.$vos["jg"].'元</div>';
		echo '<div class="sub">流量：'.round($vos_ll[0]['SUM(value)']/1024,2).'GB</div>';
		echo '<div class="sub">期限：'.$vos_ts[0]['SUM(value)'].'天</div>';
		echo '<div class="sub">可同时在线人数：'.$vos_zx[0]['SUM(value)'].'天</div>';
		echo '<br>';
		echo '<a type="button" class="btn btn-primary btn-xs" href="km_list.php?tid='.$vo['groupname'].'">管理/添加卡密</a>&nbsp;';
		echo '<button type="button" class="btn btn-primary btn-xs" onclick="window.location.href=\'add_tc.php?act=mod&id='.$vo['groupname'].'\'">编辑</button>&nbsp;';
		echo '<button type="button" class="btn btn-danger btn-xs" onclick="delLine(\''.$vo['groupname'].'\')">删除</button>&nbsp;';
		echo '<a class="btn btn-danger btn-xs" href="'.$vo["url"].'" target="_blank">购买</a>';
    echo '</div>';
    echo '</div>';
		}
	?>
   
</div>
</div>
<?php
	}
	include('footer.php');
	
?>
<script>
function qiyong(id){
	var doc = $('.line-id-'+id+' .showstatus');
	if(doc.attr('data') == "1"){
		doc.html("已禁用").attr({'data':'0'});
	}else{
		doc.html("已启用").attr({'data':'1'});
	}
	var url = "list_tc.php?act=show";
		var data = {
			"id":id,
			"show":doc.attr('data')
		};
		$.post(url,data,function(data){
			if(data.status == "success"){

			}else{
				alert("操作失败");
			}
		},"JSON");
}
function delLine(id){
	if(confirm('确认删除吗？删除后有可能会影响用户使用！')){
		$('.line-id-'+id).slideUp();
		var url = "list_tc.php?act=del";
		var data = {
			"id":id
		};
		$.post(url,data,function(data){
			if(data.status == "success"){

			}else{
				alert("删除失败");
			}
		},"JSON");
	}
}
</script>
