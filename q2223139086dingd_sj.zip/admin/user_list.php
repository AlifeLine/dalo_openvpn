﻿<?php
$mod='blank';
$title = "叮咚云控系统";
include('head.php');
include('nav.php');
if($_GET["a"] == "qset"){
	include("qset.php");
	}else{

?>
<div class="box">
<?php

$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='del'){
echo '<div class="panel panel-default">
<div class="panel-heading w h"><h3 class="panel-title">删除账号</h3></div>
<div class="panel-body box">';
$user=$_GET['user'];
$sql=db('radcheck')->where(array("username"=>$user))->delete();
if($sql){
		db('radusergroup')->where(['username'=>$_POST['username']])->delete();
		db('userinfo')->where(['username'=>$_POST['username']])->delete();
		db('cui')->where(['username'=>$_POST['username']])->delete();
		db('radacct')->where(['username'=>$_POST['username']])->delete();
		db('radpostauth')->where(['username'=>$_POST['username']])->delete();
		db('radreply')->where(['username'=>$_POST['username']])->delete();
		db('wimax')->where(['username'=>$_POST['username']])->delete();
	echo '删除成功！';
	}
else{
	echo '删除失败！';
}
echo '<hr/><a href="./user_list.php">>>返回账号列表</a></div></div>';
}

else
{

echo '<form action="user_list.php" method="get" class="form-inline">
  <div class="form-group">
    <input type="text" class="form-control" name="kw" placeholder="支持模糊搜索" value="'.$_GET["kw"].'">
  </div>
  <button type="submit" class="btn btn-primary">搜索</button>&nbsp;';
if(!empty($_GET['kw'])) {
	//$numrows = db(_openvpn_)->where(_iuser_." LIKE :kw",[":kw"=>"%".$_GET["kw"]."%"])->getnums();
	$numrows = db('radcheck')->where("username LIKE :kw",[":kw"=>"%".$_GET["kw"]."%"])->field('username')->getnums();//总用户
	$where = "username LIKE :kw";
	$data = [":kw"=>"%".$_GET["kw"]."%"];
	$con='<a href="#" class="btn btn-default">平台共有 <b>'.$numrows.'</b> 个账号</a>';
}else{
	//$numrows=$DB->count("SELECT count(*) from `openvpn` WHERE 1");
	//$numrows = db(_openvpn_)->where()->getnums();
	$numrows = db('radcheck')->field('username')->daloradius_getnums();//总用户
	$where= '';
	$con='<a href="#" class="btn btn-default">平台共有 <b>'.$numrows.'</b> 个账号</a>';
	
}
echo $con;
echo '&nbsp;<button type="button" class="btn btn-default" onclick="javascript:var n = prompt(\'统一新增流量，减少请输入负数（单位：G）\');if(!n){return false;}else{addLlAll(n)}">统一新增流量</button>';
echo '&nbsp;<button type="button" class="btn btn-default" onclick="javascript:var n = prompt(\'统一新增天数，减少请输入负数（单位：天）\');if(!n){return false;}else{addTimeAll(n)}">统一新增天数</button>';

echo '&nbsp;<button type="button" class="btn btn-default" onclick="if(!confirm(\'清理全部禁用用户？执行后不可恢复！\')){return false;}else{delAllJ()}">清理全部禁用用户</button>';
echo '</form>';
?>

      <div class="table-responsive">
        <table class="table table-striped">
          <thead><tr><th width="50">序号</th><th>账号</th><th>密码</th><th>套餐</th><th>添加时间</th><th>是否激活</th><th>状态</th><th>操作</th></tr></thead>
          <tbody>
<?php
$rs = db('radcheck')->where($where,$data)->fpage($_GET["page"],30)->order("id DESC")->select();
$i = 1;
foreach($rs as $res)
{ 
$ress = db('userinfo')->where(['username'=>$res['username']])->select();
$jihuo = db('radacct')->where(['username'=>$res['username']])->select() ? '已激活' : '未激活';
$list_user_group = db('radusergroup')->where(['username'=>$res['username']])->select();
$res_usernames_1 = $res['username'];
$zhuangtai = db('radcheck')->where(['username' => $res_usernames_1 , 'attribute' => 'boya-Disable-Password'])->select();
$starttime = strtotime($ress[0]['creationdate']);
if(date("Y-m-d",$starttime) == date("Y-m-d",time())){
	 $p = '&nbsp;<span class="label label-success">今日新增</span>';
 }elseif(date("Y-m-d",$starttime) == date("Y-m-d",(time()-24*60*60))){
	 $p = '&nbsp;<span class="label label-warning">昨日新增</span>';
	}else{
	 $p ="";
 }
// if($res["vip"] == 1){
	// $vip = '&nbsp;<span class="label label-success">VIP</span>';
// }elseif($res["vip"] == 2){
	// $vip = '&nbsp;<span class="label label-warning">VIP2</span>';
// }else{
	// $vip ="";
// }
?>
<tr class="line-id-<?=$res['username']?>">
<td><?=$i?></td>
<td><?=$res['username']?><?=$p?></td>
<td><?=$res['value']?></td>
<td><?=$list_user_group[0]['groupname']?></td>
<td><?=$ress[0]['creationdate']?></td>
<td><span class="shengyu"><?=$jihuo?></span></td>
<td><?=($zhuangtai?'禁用':'开通')?></td>
<td><a class="btn btn-default" href="./user_list.php?a=qset&user=<?=$res['username']?>">配置</a>&nbsp;<a href="javascript:void(0)" class="btn btn-primary" onclick="if(!confirm('你确实要删除此记录吗？')){return false;}else{delLine('<?=$res['username']?>')}">删除</a>&nbsp;<!--<a href="javascript:void(0)" class="btn btn-primary"   onclick="javascript:var n = prompt('请输入您要重置的流量（单位：G)');if(!n){return false;}else{addLl('<?=$res['id']?>',n)}">新增</a>--></td>
</tr>

<?php 
	$i++;
}
?>
          </tbody>
        </table>
    </div>
<?php
}
?>
   
 </div>
<script>
function addLlAll(n){
		var url = './option.php?my=addllAll';
		$.post(url,{
			"n":n
		  },function(){
			
		});
		//var m = $('.line-id-'+id+" .maxll");
		//var ne = n*1024;
		//m.html(ne);
		location.reload();
}

function addTimeAll(n){
		var url = './option.php?my=addtimeAll';
		$.post(url,{
			"n":n
		  },function(){
			
		});
	
		location.reload();
}

function addLl(id,n){
		var url = './option.php?my=addll';
		$.post(url,{
			"n":n,
			"user":id
		  },function(){
			location.reload();
		});
}
function delAllJ(){
		var url = './option.php?my=deljy';
		$.post(url,{
		  },function(){
			location.reload();
		});
}
</script>
<?php
echo create_page_html($numrows,$_GET["page"]);
	} 
include("footer.php");
?>
