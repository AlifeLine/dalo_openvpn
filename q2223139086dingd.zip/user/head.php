<?php
session_start();
//define("../app_api/config.php");
include("MM.class.php");
    $user = $_SESSION['username'];
    $pass = $_SESSION['password'];
    $ud = new MM($user,$pass);
    if(!$ud->check()){
    	echo "请登录";
    	header("location:login.php");
    }
?>


 