<?php
class MM{
private $username;
private $pwd;
public $conn;
public function __construct($username,$password){
  $this->username = $username;
  $this->pwd = $password;
}
private function radius(){
	include("../app_api/config.php");
	$conn = @mysql_connect(''._host_.':'._port_.'',''._user_.'',''._pass_.'');
    if($conn){
           //echo "链接成功";
        }else{
           //echo "链接失败";
        }
 mysql_select_db(radius,$conn);
 mysql_query('set character set  utf8');
 mysql_query('set names  utf8');
 $this->conn = $conn;
} 
public function check(){
	$this->radius();
  $query_sql = "SELECT * FROM radcheck WHERE username = '$this->username'";
  $re=mysql_query($query_sql);
    if($row=mysql_fetch_array($re)){
        $db_username = $row[1];
        $db_attribute = $row[2];
        $db_op = $row[3];
        $db_value = $row[4];
        mysql_close($this->conn);
        if ($this->username == $db_username){
            if ($db_attribute == 'Cleartext-Password' || $db_attribute == 'User-Password'){
                if ($db_value == $this->pwd)
                    return true;
            }
        }
    }else{
        return false;
	}
}
//获取流量
private function get_user_used_traffic(){
    $query_sql = "SELECT SUM(acctinputoctets + acctoutputoctets) FROM radacct WHERE username = '$this->username'";
    $re=mysql_query($query_sql);
    if($row=mysql_fetch_array($re)){
        if ($row[0] <> ''){
                return $row[0];
        }else{
                return 0;
        }
    }else{
        return false;
    }
}
//
private function get_user_used_days(){
    $query_sql = "SELECT IF(COUNT(radacctid>=1),(UNIX_TIMESTAMP() - IFNULL(UNIX_TIMESTAMP(AcctStartTime),0)),0) DIV 86400 FROM radacct WHERE username = '$this->username' AND AcctSessionTime >= 1 ORDER BY AcctStartTime LIMIT 1";
    $re=mysql_query($query_sql);
    if($row=mysql_fetch_array($re)){
        return $row[0];
    }else{
        return false;
    }

}
//
private function get_user_total_traffic(){
    $max_global_traffic = 0;
    $max_active_days = 0;
    $query_sql = "SELECT groupname FROM radusergroup WHERE username = '$this->username'";
    $re=mysql_query($query_sql);
    if($row=mysql_fetch_array($re)){
        $groupname = $row[0];
          $query_sql1 = "SELECT * FROM radgroupcheck WHERE groupname = '$groupname'";
          $re1=mysql_query($query_sql1);
          $max_global_traffic=100*1024*1024;
          while($row1=mysql_fetch_array($re1)){
              if ("Max-Global-Traffic" == $row1[2]){
                  $max_global_traffic = $row1[4];
              }elseif("Max-Active-Days" == $row1[2]){
                  $max_active_days = $row1[4];
              }
          }

    }
    $max=array();
    $max[0]=$max_global_traffic;
    $max[1]=$max_active_days;
    return $max;

}
public function getllts(){
	  $data=array();
    $this->radius();
    $cur_traffic = $this->get_user_used_traffic();
    $data['globalTrafficCount'] = round($cur_traffic/1024/1024/1024,2);
    $umax = $this->get_user_total_traffic();
    $max_global_traffic= round($umax[0]/1024,2);
    $max_active_days=$umax[1];
    $data['maxGlobalTraffic'] = $max_global_traffic;
	  $data['maxActiveDays'] =$max_active_days;
	  $data['activeDaysCount'] = $this->get_user_used_days();
	  $info=array();
	  $info[0] = $umax[0]*1024*1024-$cur_traffic;//剩余ll
	  $info[1] = $data['maxActiveDays']-$data['activeDaysCount'];//剩余天数
	  $info[2] = $umax[0]*1024*1024;//总ll
	  $info[3] = $data['maxActiveDays'];//总天数
	  $info[4] = $cur_traffic;//使用的ll
	  mysql_close($this->conn);
	  return $info;
}
}
?>
